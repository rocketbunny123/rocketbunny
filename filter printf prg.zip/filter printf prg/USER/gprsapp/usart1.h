#ifndef __USART1_H
#define	__USART1_H

#include "stm32f10x.h"
#include <stdio.h>

typedef struct uartTag
{
  uint8_t RcvState;
  uint8_t SndState;
  uint8_t head_status;
  uint8_t end_status;
  uint8_t RxSuccessFlag;
  uint8_t endtmp_;
  uint8_t RcvError;

	uint8_t uartRxBuff_Tmp[100],uartTxBuff_Tmp[100];
	uint16_t uartRxBuffPos,uartTxBuffPos,RcvDataLength,DataLength;
}uartTag;

typedef enum
{
	STATE_RX1_IDLE=0,  //����̬
	STATE_RX1_RCV,   //����̬      
	STATE_RX1_END,   //����̬
	STATE_RX1_ERROR  //����̬   
}uart1RcvState;

void gprs_uart_init(void);
int fputc(int ch, FILE *f);
void usart_sent_char(USART_TypeDef* USARTx,u8 ch);
void usart_sent_string(USART_TypeDef* USARTx,uint8_t *ch);
void GPRSend(uint8_t *ch);

#endif 
