#ifndef _HW_CONFIG_H
#define _HW_CONFIG_H

#include "stm32f10x.h"
#include "stm32f10x_flash.h"

void Set_System(void);
void Interrupts_Config(void);
void delay_ms(uint16_t nms);

#endif
