#ifndef __TIMER_H
#define __TIMER_H

#include "stm32f10x.h"
#include <stdio.h>

void TIM2_Int_Init(u16 arr,u16 psc);

void TIM3_Int_Init(u16 arr,u16 psc);

#define TIM_ENABLE(TIMX) TIM_Cmd(TIMX,ENABLE)

#define TIM_DISABLE(TIMX) TIM_Cmd(TIMX,DISABLE)

#endif 
