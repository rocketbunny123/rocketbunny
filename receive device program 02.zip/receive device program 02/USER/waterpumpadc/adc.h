#ifndef __ADC_H
#define	__ADC_H


#include "stm32f10x.h"

#define ADC_GPIO_PORT GPIOA

#define Torque_GPIO GPIO_Pin_1

#define Flow_GPIO GPIO_Pin_3


void ADC1_Init(void);



#endif /* __ADC_H */

